(function attach(root) {
  "use strict";

  var SAMPLE_CSV = [
    "sku,product_name,inventory_on_hand,units_sold_30d,units_sold_90d,lead_time_days,unit_cost,vendor,category,reorder_multiple,incoming_units,committed_units",
    "SKU-1001,Bamboo Storage Bin - Small,42,90,260,28,8.50,Northstar Home,Storage,12,0,10",
    "SKU-1002,Bamboo Storage Bin - Large,18,72,210,35,12.25,Northstar Home,Storage,12,24,0",
    "SKU-1003,Silicone Travel Bottle Set,240,12,35,21,3.10,Blue Ridge Goods,Travel,24,0,5",
    "SKU-1004,Cotton Drawer Organizer,6,48,150,30,4.75,Northstar Home,Storage,12,0,4",
    "SKU-1005,Reusable Produce Bag Set,310,0,0,45,2.20,Greenline Supply,Kitchen,50,0,0",
    "SKU-1006,Magnetic Spice Labels,88,30,95,14,1.40,LabelWorks,Kitchen,20,0,0",
    "SKU-1007,Glass Meal Prep Container 3pk,12,6,22,60,10.80,Blue Ridge Goods,Kitchen,6,0,8",
    "SKU-1008,Linen Closet Divider,0,25,70,28,5.90,Northstar Home,Storage,10,40,0",
    "SKU-1009,Compostable Shipping Mailer 50pk,500,150,420,20,6.30,PackRight,Shipping,25,0,25",
    "SKU-1010,Holiday Gift Wrap Bundle,120,0,6,50,7.25,Seasonal House,Seasonal,12,0,0"
  ].join("\n");

  var REQUIRED_FIELDS = ["sku", "product_name", "inventory_on_hand", "units_sold_30d", "units_sold_90d", "lead_time_days"];
  var OPTIONAL_FIELDS = ["unit_cost", "vendor", "category", "reorder_multiple", "incoming_units", "committed_units"];
  var NUMERIC_FIELDS = [
    "inventory_on_hand",
    "units_sold_30d",
    "units_sold_90d",
    "lead_time_days",
    "unit_cost",
    "reorder_multiple",
    "incoming_units",
    "committed_units"
  ];
  var OPTIONAL_COPY = {
    unit_cost: ["Cash tied up and estimated cash for reorder enabled", "Cash tied up and reorder cash unavailable"],
    vendor: ["Supplier draft personalized", "Supplier draft uses a generic greeting"],
    category: ["Category available for segmentation", "Category not available for segmentation"],
    reorder_multiple: ["Reorder qty rounded to MOQ or pack multiple", "Reorder qty not rounded to MOQ"],
    incoming_units: ["Inbound counted in effective inventory", "Inbound not counted"],
    committed_units: ["Committed units subtracted from available inventory", "Committed units default to 0"]
  };

  var state = {
    rows: [],
    headers: [],
    dataQuality: null,
    summary: null,
    selectedSku: null,
    templateOverride: null,
    activeTab: "overview",
    stockoutSort: { key: "urgency", direction: "asc" },
    status: "empty"
  };

  // Anonymous behavioral counter - no network, no cookie, no third-party.
  // Default: no-op. A future PR (Esther-approved) can swap in a cookieless destination.
  function track(event, props) {
    var safeProps = props || {};
    if (root.__DEBUG_TRACK && root.console && typeof root.console.debug === "function") {
      root.console.debug("[track]", event, safeProps);
    }
  }

  function escapeHtml(value) {
    return String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function parseCsv(text) {
    var rows = [];
    var current = "";
    var row = [];
    var inQuotes = false;
    var i;
    var char;
    var next;

    for (i = 0; i < text.length; i += 1) {
      char = text[i];
      next = text[i + 1];
      if (char === '"' && inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === "," && !inQuotes) {
        row.push(current);
        current = "";
      } else if ((char === "\n" || char === "\r") && !inQuotes) {
        if (char === "\r" && next === "\n") i += 1;
        row.push(current);
        if (row.some(function hasValue(cell) { return String(cell).trim() !== ""; })) rows.push(row);
        row = [];
        current = "";
      } else {
        current += char;
      }
    }

    row.push(current);
    if (row.some(function hasValue(cell) { return String(cell).trim() !== ""; })) rows.push(row);
    if (!rows.length) return { headers: [], rows: [] };

    var headers = rows[0].map(function header(cell) { return String(cell).trim(); });
    return {
      headers: headers,
      rows: rows.slice(1).map(function mapRow(cells) {
        var item = {};
        headers.forEach(function eachHeader(header, index) {
          item[header] = cells[index] === undefined ? "" : String(cells[index]).trim();
        });
        return item;
      })
    };
  }

  function toNumber(value) {
    if (value === null || value === undefined || value === "") return null;
    var cleaned = String(value).replace(/[$,]/g, "").trim();
    if (cleaned === "") return null;
    var parsed = Number(cleaned);
    return Number.isFinite(parsed) ? parsed : NaN;
  }

  function validateHeaders(headers) {
    var normalized = headers.map(function lower(header) { return header.toLowerCase(); });
    var missing = REQUIRED_FIELDS.filter(function missingField(field) {
      return normalized.indexOf(field) === -1;
    });
    return missing.map(function message(field) {
      return "Missing required column: " + field;
    });
  }

  function normalizeRow(row, index) {
    var normalized = {
      rowIndex: index + 2,
      sku: String(row.sku || "").trim(),
      product_name: String(row.product_name || "").trim(),
      vendor: String(row.vendor || "").trim(),
      category: String(row.category || "").trim(),
      source: row
    };

    NUMERIC_FIELDS.forEach(function assign(field) {
      var value = toNumber(row[field]);
      if (value === null && (field === "incoming_units" || field === "committed_units")) value = 0;
      normalized[field] = value;
    });

    return normalized;
  }

  function validateRows(rawRows) {
    var errors = [];
    var normalizedRows = rawRows.map(normalizeRow);
    var seenSkus = {};

    normalizedRows.forEach(function validate(row) {
      if (!row.sku) errors.push("Blank sku in row " + row.rowIndex);
      if (!row.product_name) errors.push("Blank product_name for SKU " + (row.sku || "row " + row.rowIndex));
      if (row.sku) {
        if (seenSkus[row.sku]) errors.push("Duplicate SKU found: " + row.sku);
        seenSkus[row.sku] = true;
      }

      REQUIRED_FIELDS.forEach(function checkRequired(field) {
        if (field === "sku" || field === "product_name") return;
        if (row[field] === null || Number.isNaN(row[field])) {
          errors.push("Invalid number in " + field + " for SKU " + (row.sku || "row " + row.rowIndex));
        }
      });

      OPTIONAL_FIELDS.forEach(function checkOptional(field) {
        if (field === "vendor" || field === "category") return;
        if (row.source[field] !== undefined && String(row.source[field]).trim() !== "" && Number.isNaN(row[field])) {
          errors.push("Invalid number in " + field + " for SKU " + (row.sku || "row " + row.rowIndex));
        }
      });

      if (row.inventory_on_hand < 0) errors.push("Negative inventory is not supported in v0: " + row.sku);
      if (row.units_sold_30d < 0) errors.push("Negative units_sold_30d is not supported in v0: " + row.sku);
      if (row.units_sold_90d < 0) errors.push("Negative units_sold_90d is not supported in v0: " + row.sku);
      if (row.incoming_units < 0) errors.push("Negative incoming_units is not supported in v0: " + row.sku);
      if (row.committed_units < 0) errors.push("Negative committed_units is not supported in v0: " + row.sku);
      if (row.lead_time_days < 0 || row.lead_time_days > 365) errors.push("lead_time_days must be between 0 and 365 for SKU " + row.sku);
      if (row.unit_cost !== null && row.unit_cost < 0) errors.push("unit_cost cannot be negative for SKU " + row.sku);
      if (row.reorder_multiple !== null && row.reorder_multiple <= 0) errors.push("reorder_multiple must be greater than 0 for SKU " + row.sku);
    });

    if (!rawRows.length) errors.push("CSV must contain at least 1 analyzable row");
    return { errors: errors, rows: errors.length ? [] : normalizedRows };
  }

  function round(value, decimals) {
    var factor = Math.pow(10, decimals || 0);
    return Math.round((value + Number.EPSILON) * factor) / factor;
  }

  function roundUpToMultiple(value, multiple) {
    if (!(multiple > 0)) return Math.ceil(value);
    return Math.ceil(value / multiple) * multiple;
  }

  function computeSafetyBufferDays(leadTimeDays) {
    return Math.max(7, Math.ceil(0.25 * leadTimeDays));
  }

  function calculateInventoryMetrics(row) {
    var averageDailySales30d = row.units_sold_30d / 30;
    var averageDailySales90d = row.units_sold_90d / 90;
    var dailyVelocity = Math.max(averageDailySales30d, averageDailySales90d);
    var committed = row.committed_units || 0;
    var incoming = row.incoming_units || 0;
    var availableInventory = Math.max(0, row.inventory_on_hand - committed);
    var effectiveInventory = availableInventory + incoming;
    var daysOfCover = dailyVelocity > 0 ? effectiveInventory / dailyVelocity : Infinity;
    var safetyBufferDays = computeSafetyBufferDays(row.lead_time_days);
    var highThreshold = row.lead_time_days + safetyBufferDays;
    var mediumThreshold = highThreshold + 14;
    var stockoutRisk = "low";
    var urgency = "HOLD";
    var targetCoverDays = row.lead_time_days + 30;
    var rawReorderQuantity = dailyVelocity > 0 ? Math.max(0, targetCoverDays * dailyVelocity - effectiveInventory) : 0;
    var reorderQuantity = roundUpToMultiple(rawReorderQuantity, row.reorder_multiple);
    var hasCost = row.unit_cost !== null && !Number.isNaN(row.unit_cost);
    var cashTiedUp = hasCost ? row.inventory_on_hand * row.unit_cost : null;
    var estimatedCashForReorder = hasCost ? reorderQuantity * row.unit_cost : null;
    var projectedDaysShort = dailyVelocity > 0 ? Math.max(0, row.lead_time_days - daysOfCover) : 0;
    var deadstockCandidate = row.inventory_on_hand > 0 && (daysOfCover > 180 || (dailyVelocity <= 0 && row.units_sold_30d === 0));
    var deadstockRisk = "low";

    if (dailyVelocity > 0 && daysOfCover <= highThreshold) stockoutRisk = "high";
    else if (dailyVelocity > 0 && daysOfCover <= mediumThreshold) stockoutRisk = "medium";

    if (dailyVelocity > 0 && daysOfCover < row.lead_time_days) urgency = "EXPEDITE";
    else if (dailyVelocity > 0 && daysOfCover < row.lead_time_days + safetyBufferDays) urgency = "REORDER";

    if (deadstockCandidate) {
      deadstockRisk = row.units_sold_30d === 0 || row.units_sold_90d === 0 ? "high" : "medium";
    }

    return {
      averageDailySales30d: averageDailySales30d,
      averageDailySales90d: averageDailySales90d,
      dailyVelocity: dailyVelocity,
      availableInventory: availableInventory,
      effectiveInventory: effectiveInventory,
      daysOfCover: daysOfCover,
      safetyBufferDays: safetyBufferDays,
      stockoutRisk: stockoutRisk,
      urgency: urgency,
      reorderQuantity: reorderQuantity,
      rawReorderQuantity: rawReorderQuantity,
      cashTiedUp: cashTiedUp,
      estimatedCashForReorder: estimatedCashForReorder,
      projectedDaysShort: projectedDaysShort,
      deadstockCandidate: deadstockCandidate,
      deadstockRisk: deadstockRisk
    };
  }

  function evaluateCaveats(row, metrics) {
    return {
      newlyActiveSku: row.units_sold_30d > 0 && row.units_sold_90d < row.units_sold_30d * 2.5,
      offSeasonCandidate: metrics.deadstockCandidate,
      committedExceedsOnHand: row.committed_units > row.inventory_on_hand
    };
  }

  function determineAction(rowWithMetrics) {
    var metrics = rowWithMetrics.metrics;
    if (rowWithMetrics.validationIssue) return "review";
    if (metrics.deadstockCandidate) return "markdown";
    if (metrics.stockoutRisk === "high" && metrics.daysOfCover < rowWithMetrics.lead_time_days && metrics.reorderQuantity > 0) return "expedite";
    if (metrics.stockoutRisk === "high" && metrics.reorderQuantity > 0) return "reorder";
    return "hold";
  }

  function enrichRows(rows) {
    return rows.map(function enrich(row) {
      var metrics = calculateInventoryMetrics(row);
      var caveats = evaluateCaveats(row, metrics);
      var enriched = Object.assign({}, row, { metrics: metrics, caveats: caveats });
      enriched.action = determineAction(enriched);
      enriched.defaultTemplate = selectSupplierTemplate(enriched);
      return enriched;
    });
  }

  function selectSupplierTemplate(row) {
    return row.action === "expedite" ? "urgent_expedite" : "standard_reorder";
  }

  function analyticsTemplateName(templateKey) {
    return templateKey === "urgent_expedite" ? "urgent" : "standard";
  }

  function fmtNumber(value, decimals) {
    if (value === null || value === undefined || Number.isNaN(value)) return "-";
    if (!Number.isFinite(value)) return "No recent sales";
    return Number(value).toLocaleString("en-US", {
      minimumFractionDigits: decimals || 0,
      maximumFractionDigits: decimals || 0
    });
  }

  function fmtDays(value) {
    if (!Number.isFinite(value)) return "No recent sales";
    if (value < 10) return fmtNumber(value, 1);
    return fmtNumber(value, 0);
  }

  function fmtMoney(value) {
    if (value === null || value === undefined || Number.isNaN(value)) return "-";
    return "$" + Number(value).toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
  }

  function actionLabel(row) {
    if (row.action === "expedite") return "EXPEDITE - projected " + fmtNumber(Math.ceil(row.metrics.projectedDaysShort), 0) + " days short";
    if (row.action === "reorder") return "REORDER";
    if (row.action === "markdown") return "DEADSTOCK CANDIDATE";
    if (row.action === "review") return "REVIEW DATA";
    return "HOLD";
  }

  function actionClass(row) {
    if (row.action === "markdown") return "deadstock";
    return row.action;
  }

  function buildSupplierDraft(row, templateKey) {
    var vendor = row.vendor || "Supplier team";
    var requestedBy = new Date();
    requestedBy.setDate(requestedBy.getDate() + Math.ceil(row.lead_time_days));
    var dateText = requestedBy.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    var lastCost = row.metrics.estimatedCashForReorder === null ? "-" : "$" + row.unit_cost.toFixed(2);
    var standard = [
      "Subject: Reorder request for " + row.sku + " - " + row.product_name,
      "",
      "Hi " + vendor + ",",
      "",
      "Can you confirm availability for a reorder of " + fmtNumber(row.metrics.reorderQuantity, 0) + " units of " + row.product_name + " (" + row.sku + ")?",
      "",
      "Current planning details:",
      "- On hand: " + fmtNumber(row.inventory_on_hand, 0) + " units",
      "- Incoming units already expected: " + fmtNumber(row.incoming_units || 0, 0),
      "- Current days of cover: " + fmtDays(row.metrics.daysOfCover),
      "- Standard lead time: " + fmtNumber(row.lead_time_days, 0) + " days",
      "- Requested by: " + dateText,
      "- Last unit cost: " + lastCost,
      "",
      "Please confirm:",
      "1. Availability and updated lead time",
      "2. Current pricing and MOQ or pack multiple",
      "3. Earliest ship date"
    ].join("\n");
    var urgent = [
      "Subject: Urgent expedite request for " + row.sku + " - " + row.product_name,
      "",
      "Hi " + vendor + ",",
      "",
      "This SKU may run short before the normal replenishment window. Can you confirm the fastest option for " + fmtNumber(row.metrics.reorderQuantity, 0) + " units of " + row.product_name + " (" + row.sku + ")?",
      "",
      "Current planning details:",
      "- On hand: " + fmtNumber(row.inventory_on_hand, 0) + " units",
      "- Days of cover: " + fmtDays(row.metrics.daysOfCover),
      "- Standard lead time: " + fmtNumber(row.lead_time_days, 0) + " days",
      "- Projected days short: " + fmtNumber(Math.ceil(row.metrics.projectedDaysShort), 0),
      "- Requested reorder quantity: " + fmtNumber(row.metrics.reorderQuantity, 0) + " units",
      "",
      "Please confirm:",
      "1. Fastest possible ship date",
      "2. Expedite or air-freight cost option",
      "3. Whether a partial early shipment is available"
    ].join("\n");

    return templateKey === "urgent_expedite" ? urgent : standard;
  }

  function summarizeDataQuality(headers, rows, errors) {
    var normalizedHeaders = headers.map(function lower(header) { return header.toLowerCase(); });
    var optional = OPTIONAL_FIELDS.map(function item(field) {
      var present = normalizedHeaders.indexOf(field) !== -1;
      return {
        field: field,
        present: present,
        consequence: present ? OPTIONAL_COPY[field][0] : OPTIONAL_COPY[field][1]
      };
    });
    var warningCounts = {
      newlyActiveSku: rows.filter(function count(row) { return row.caveats.newlyActiveSku; }).length,
      committedExceedsOnHand: rows.filter(function count(row) { return row.caveats.committedExceedsOnHand; }).length,
      reviewData: errors ? errors.length : 0
    };
    return {
      optional: optional,
      optionalUsedCount: optional.filter(function used(item) { return item.present; }).length,
      warnings: warningCounts
    };
  }

  function summarizePortfolio(rows) {
    var actionCounts = rows.reduce(function count(map, row) {
      map[row.action] = (map[row.action] || 0) + 1;
      return map;
    }, {});
    var stockoutHigh = rows.filter(function count(row) { return row.metrics.stockoutRisk === "high"; }).length;
    var deadstock = rows.filter(function count(row) { return row.metrics.deadstockCandidate; }).length;
    var totalCashTiedUp = rows.reduce(function sum(total, row) {
      return total + (row.metrics.deadstockCandidate && row.metrics.cashTiedUp ? row.metrics.cashTiedUp : 0);
    }, 0);
    var reorderCash = rows.reduce(function sum(total, row) {
      return total + (row.action === "expedite" || row.action === "reorder" ? (row.metrics.estimatedCashForReorder || 0) : 0);
    }, 0);
    return {
      skuCount: rows.length,
      stockoutHigh: stockoutHigh,
      deadstock: deadstock,
      totalCashTiedUp: totalCashTiedUp,
      reorderCash: reorderCash,
      actionCounts: actionCounts,
      actionNeeded: rows.filter(function count(row) { return row.action !== "hold"; }).length
    };
  }

  function analyzeCsv(text) {
    var parsed = parseCsv(text);
    var headerErrors = validateHeaders(parsed.headers);
    if (headerErrors.length) return { ok: false, errors: headerErrors, headers: parsed.headers, rows: [] };
    var validated = validateRows(parsed.rows);
    if (validated.errors.length) return { ok: false, errors: validated.errors, headers: parsed.headers, rows: [] };
    var rows = enrichRows(validated.rows);
    return {
      ok: true,
      errors: [],
      headers: parsed.headers,
      rows: rows,
      dataQuality: summarizeDataQuality(parsed.headers, rows, []),
      summary: summarizePortfolio(rows)
    };
  }

  function recalcRowForLeadTimeEdit(row, newLeadTimeDays) {
    var next = Object.assign({}, row, { lead_time_days: newLeadTimeDays });
    var metrics = calculateInventoryMetrics(next);
    var caveats = evaluateCaveats(next, metrics);
    next.metrics = metrics;
    next.caveats = caveats;
    next.action = determineAction(next);
    next.defaultTemplate = selectSupplierTemplate(next);
    return next;
  }

  function setStatus(title, detail) {
    var titleEl = document.querySelector("[data-status-title]");
    var detailEl = document.querySelector("[data-status-detail]");
    if (titleEl) titleEl.textContent = title;
    if (detailEl) detailEl.textContent = detail;
  }

  function hideEmptyState() {
    var empty = document.querySelector("[data-empty-state]");
    if (empty) empty.hidden = state.rows.length > 0;
  }

  function clearResultRoots() {
    [
      "[data-overview-root]",
      "[data-stockout-root]",
      "[data-deadstock-root]",
      "[data-supplier-root]"
    ].forEach(function clear(selector) {
      var el = document.querySelector(selector);
      if (el) el.innerHTML = "";
    });
    var stockoutCount = document.querySelector("[data-nav-count='stockout']");
    var deadstockCount = document.querySelector("[data-nav-count='deadstock']");
    if (stockoutCount) stockoutCount.textContent = "";
    if (deadstockCount) deadstockCount.textContent = "";
  }

  function showErrors(errors) {
    var panel = document.querySelector("[data-error-panel]");
    if (!panel) return;
    if (!errors || !errors.length) {
      panel.hidden = true;
      panel.innerHTML = "";
      return;
    }
    panel.hidden = false;
    panel.innerHTML = [
      "<h2>We couldn't analyze this CSV yet</h2>",
      "<p>Fix the issues below or try the sample file.</p>",
      "<ul>" + errors.map(function error(item) { return "<li>" + escapeHtml(item) + "</li>"; }).join("") + "</ul>"
    ].join("");
  }

  function metricCard(label, value) {
    return "<article class=\"metric-card\"><span>" + escapeHtml(label) + "</span><strong>" + escapeHtml(value) + "</strong></article>";
  }

  function sortedActionRows() {
    var priority = { expedite: 1, reorder: 2, markdown: 3, review: 4, hold: 5 };
    return state.rows.slice().sort(function compare(a, b) {
      var pa = priority[a.action] || 9;
      var pb = priority[b.action] || 9;
      if (pa !== pb) return pa - pb;
      if (a.metrics.daysOfCover !== b.metrics.daysOfCover) return a.metrics.daysOfCover - b.metrics.daysOfCover;
      return a.sku.localeCompare(b.sku);
    });
  }

  function renderDataQuality() {
    if (!state.dataQuality) return "";
    var dq = state.dataQuality;
    var warningItems = [];
    if (dq.warnings.newlyActiveSku) warningItems.push("Newly active SKU: " + dq.warnings.newlyActiveSku + " rows");
    if (dq.warnings.committedExceedsOnHand) warningItems.push("Committed exceeds on-hand: " + dq.warnings.committedExceedsOnHand + " rows. Available inventory is floored at 0.");
    if (dq.warnings.reviewData) warningItems.push("Review data: " + dq.warnings.reviewData + " rows");
    if (!warningItems.length) warningItems.push("No row-level data quality warnings in this file.");
    return [
      "<section class=\"data-quality\">",
      "<div><h2>Data Quality</h2><p>Analyzed with " + dq.optionalUsedCount + " of 6 optional fields. Optional gaps do not block analysis.</p></div>",
      "<div class=\"dq-grid\">",
      dq.optional.map(function item(field) {
        return "<div class=\"dq-row\"><strong>" + (field.present ? "Used" : "Missing") + ": " + escapeHtml(field.field) + "</strong><span>" + escapeHtml(field.consequence) + "</span></div>";
      }).join(""),
      "</div>",
      "<ul class=\"warn-list\">" + warningItems.map(function warn(item) { return "<li>" + escapeHtml(item) + "</li>"; }).join("") + "</ul>",
      "</section>"
    ].join("");
  }

  function renderActionList() {
    var rows = sortedActionRows();
    return "<div class=\"action-list\">" + rows.map(function rowHtml(row, index) {
      var caveat = row.caveats.newlyActiveSku ? "<span class=\"pill neutral\">Newly active SKU</span>" : "";
      return [
        "<article class=\"action-item\" data-action-card=\"" + escapeHtml(row.sku) + "\">",
        "<div class=\"action-main\">",
        "<button class=\"action-rank\" type=\"button\" data-toggle-action=\"" + escapeHtml(row.sku) + "\">" + (index + 1) + "</button>",
        "<div class=\"sku-line\"><strong>" + escapeHtml(row.sku) + " - " + escapeHtml(row.product_name) + "</strong><span>" + fmtDays(row.metrics.daysOfCover) + " days cover | lead time " + fmtNumber(row.lead_time_days, 0) + " days | reorder " + fmtNumber(row.metrics.reorderQuantity, 0) + " units</span></div>",
        "<span class=\"pill " + actionClass(row) + "\">" + escapeHtml(actionLabel(row)) + "</span>",
        "</div>",
        "<div class=\"action-detail\">",
        "<div class=\"detail-stat\"><span>Available inventory</span><strong>" + fmtNumber(row.metrics.availableInventory, 0) + "</strong></div>",
        "<div class=\"detail-stat\"><span>Effective inventory</span><strong>" + fmtNumber(row.metrics.effectiveInventory, 0) + "</strong></div>",
        "<div class=\"detail-stat\"><span>Reorder cash</span><strong>" + fmtMoney(row.metrics.estimatedCashForReorder) + "</strong></div>",
        "<div class=\"detail-stat\"><span>Caveat</span><strong>" + (caveat || (row.caveats.offSeasonCandidate ? "Off-season candidate" : "None")) + "</strong></div>",
        "<div class=\"button-row\"><button class=\"secondary-button\" type=\"button\" data-select-supplier=\"" + escapeHtml(row.sku) + "\">Draft supplier email</button></div>",
        "</div>",
        "</article>"
      ].join("");
    }).join("") + "</div>";
  }

  function renderOverview() {
    var rootEl = document.querySelector("[data-overview-root]");
    if (!rootEl || !state.summary) return;
    var s = state.summary;
    var headline = s.actionNeeded ? s.actionNeeded + " SKUs need action or review this week" : "Most SKUs look stable this week";
    rootEl.innerHTML = [
      "<div class=\"results-grid\">",
      "<div class=\"panel\">",
      "<div class=\"panel-header\"><div><h2>" + escapeHtml(headline) + "</h2><p>Action list is ranked by urgency first, then days of cover.</p></div></div>",
      "<div class=\"metric-grid\">",
      metricCard("SKUs analyzed", fmtNumber(s.skuCount, 0)),
      metricCard("High stockout risk", fmtNumber(s.stockoutHigh, 0)),
      metricCard("Deadstock candidates", fmtNumber(s.deadstock, 0)),
      metricCard("Deadstock cash at risk", fmtMoney(s.totalCashTiedUp)),
      "</div>",
      renderActionList(),
      "</div>",
      renderDataQuality(),
      "</div>"
    ].join("");
  }

  function riskRank(row) {
    if (row.action === "expedite") return 1;
    if (row.action === "reorder") return 2;
    if (row.metrics.stockoutRisk === "medium") return 3;
    return 4;
  }

  function stockoutRows() {
    var rows = state.rows.slice();
    var sort = state.stockoutSort;
    rows.sort(function compare(a, b) {
      var av;
      var bv;
      if (sort.key === "sku") {
        av = a.sku;
        bv = b.sku;
      } else if (sort.key === "cover") {
        av = a.metrics.daysOfCover;
        bv = b.metrics.daysOfCover;
      } else if (sort.key === "lead") {
        av = a.lead_time_days;
        bv = b.lead_time_days;
      } else if (sort.key === "reorder") {
        av = a.metrics.reorderQuantity;
        bv = b.metrics.reorderQuantity;
      } else {
        av = riskRank(a);
        bv = riskRank(b);
      }
      if (typeof av === "string") return sort.direction === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      if (av === bv) return a.sku.localeCompare(b.sku);
      return sort.direction === "asc" ? av - bv : bv - av;
    });
    return rows;
  }

  function renderStockout() {
    var rootEl = document.querySelector("[data-stockout-root]");
    if (!rootEl) return;
    rootEl.innerHTML = [
      "<section class=\"table-card\">",
      "<div class=\"panel-header\"><div><h2>Stockout Risk</h2><p>Inline lead-time edits recalculate that SKU in the browser without re-uploading the CSV.</p></div></div>",
      "<div class=\"banner\"><strong>Verify net of returns.</strong> Make sure units_sold_30d and units_sold_90d are NET of returns. Shopify's default order export is gross.</div>",
      "<div class=\"table-wrap\"><table>",
      "<thead><tr>",
      "<th class=\"sortable\" data-sort-stockout=\"sku\">SKU</th>",
      "<th>Product</th>",
      "<th class=\"sortable\" data-sort-stockout=\"cover\">Days cover</th>",
      "<th class=\"sortable\" data-sort-stockout=\"lead\">Lead time</th>",
      "<th>Risk</th>",
      "<th class=\"sortable\" data-sort-stockout=\"reorder\">Reorder qty</th>",
      "<th>Action</th>",
      "</tr></thead>",
      "<tbody>",
      stockoutRows().map(function rowHtml(row) {
        return [
          "<tr>",
          "<td><strong>" + escapeHtml(row.sku) + "</strong>" + (row.caveats.newlyActiveSku ? "<br><span class=\"pill neutral\">Newly active SKU</span>" : "") + "</td>",
          "<td>" + escapeHtml(row.product_name) + "<br><span class=\"small-muted\">" + escapeHtml(row.vendor || "Supplier missing") + "</span></td>",
          "<td>" + fmtDays(row.metrics.daysOfCover) + "</td>",
          "<td><input class=\"lead-input\" type=\"number\" min=\"0\" max=\"365\" value=\"" + escapeHtml(row.lead_time_days) + "\" data-lead-edit=\"" + escapeHtml(row.sku) + "\"></td>",
          "<td><span class=\"pill " + (row.metrics.stockoutRisk === "high" ? "expedite" : row.metrics.stockoutRisk === "medium" ? "reorder" : "hold") + "\">" + escapeHtml(row.metrics.stockoutRisk.toUpperCase()) + "</span></td>",
          "<td><strong>" + fmtNumber(row.metrics.reorderQuantity, 0) + " units</strong><br><span class=\"small-muted\">" + fmtMoney(row.metrics.estimatedCashForReorder) + " est. cash</span></td>",
          "<td><button class=\"link-button\" type=\"button\" data-select-supplier=\"" + escapeHtml(row.sku) + "\"><span class=\"pill " + actionClass(row) + "\">" + escapeHtml(actionLabel(row)) + "</span></button></td>",
          "</tr>"
        ].join("");
      }).join(""),
      "</tbody></table></div>",
      "</section>"
    ].join("");
  }

  function renderDeadstock() {
    var rootEl = document.querySelector("[data-deadstock-root]");
    if (!rootEl) return;
    var rows = state.rows.filter(function filter(row) { return row.metrics.deadstockCandidate; })
      .sort(function compare(a, b) { return (b.metrics.cashTiedUp || 0) - (a.metrics.cashTiedUp || 0); });
    rootEl.innerHTML = [
      "<section class=\"table-card\">",
      "<div class=\"panel-header\"><div><h2>Deadstock cash at risk</h2><p>Cash shown here is limited to deadstock-candidate SKUs. Confirm seasonality and assortment plans before marking down.</p></div></div>",
      rows.length ? "<div class=\"table-wrap\"><table><thead><tr><th>SKU</th><th>Product</th><th>On hand</th><th>Units sold 90d</th><th>Risk</th><th>Cash tied up</th><th>Caveat</th></tr></thead><tbody>" + rows.map(function rowHtml(row) {
        return [
          "<tr>",
          "<td><strong>" + escapeHtml(row.sku) + "</strong></td>",
          "<td>" + escapeHtml(row.product_name) + "</td>",
          "<td>" + fmtNumber(row.inventory_on_hand, 0) + "</td>",
          "<td>" + fmtNumber(row.units_sold_90d, 0) + "</td>",
          "<td><span class=\"pill deadstock\">" + escapeHtml(row.metrics.deadstockRisk.toUpperCase()) + "</span></td>",
          "<td>" + fmtMoney(row.metrics.cashTiedUp) + "</td>",
          "<td>Off-season SKUs may appear here. Confirm against your assortment calendar before marking down.</td>",
          "</tr>"
        ].join("");
      }).join("") + "</tbody></table></div>" : "<p>No deadstock candidates found in this file.</p>",
      "</section>"
    ].join("");
  }

  function supplierRows() {
    return state.rows.filter(function filter(row) {
      return row.action === "expedite" || row.action === "reorder" || row.metrics.stockoutRisk === "high";
    }).sort(function compare(a, b) { return riskRank(a) - riskRank(b) || a.metrics.daysOfCover - b.metrics.daysOfCover; });
  }

  function selectedSupplierRow() {
    var rows = supplierRows();
    if (!rows.length) return state.rows[0] || null;
    return rows.find(function find(row) { return row.sku === state.selectedSku; }) || rows[0];
  }

  function renderSupplier() {
    var rootEl = document.querySelector("[data-supplier-root]");
    if (!rootEl) return;
    var rows = supplierRows();
    var selected = selectedSupplierRow();
    if (!selected) {
      rootEl.innerHTML = "<section class=\"panel\"><h2>Supplier Draft</h2><p>Load a CSV to generate deterministic supplier copy.</p></section>";
      return;
    }
    state.selectedSku = selected.sku;
    var templateKey = state.templateOverride || selected.defaultTemplate;
    var switchKey = templateKey === "urgent_expedite" ? "standard_reorder" : "urgent_expedite";
    rootEl.innerHTML = [
      "<section class=\"panel\">",
      "<div class=\"panel-header\"><div><h2>Supplier Draft</h2><p>Two deterministic templates are available. Urgent expedite is auto-selected when days of cover is below lead time.</p></div><button class=\"copy-button\" type=\"button\" data-copy-draft>Copy draft</button></div>",
      "<div class=\"draft-layout\">",
      "<div class=\"sku-selector\">",
      rows.map(function option(row) {
        return "<button class=\"sku-select-button " + (row.sku === selected.sku ? "is-active" : "") + "\" type=\"button\" data-select-supplier=\"" + escapeHtml(row.sku) + "\"><strong>" + escapeHtml(row.sku) + "</strong><br><span class=\"small-muted\">" + escapeHtml(actionLabel(row)) + "</span></button>";
      }).join(""),
      "</div>",
      "<div>",
      "<div class=\"template-toggle\"><span class=\"pill " + (templateKey === "urgent_expedite" ? "expedite" : "reorder") + "\">" + (templateKey === "urgent_expedite" ? "Urgent expedite template" : "Standard reorder template") + "</span> <button class=\"link-button\" type=\"button\" data-switch-template=\"" + switchKey + "\">Switch to " + (switchKey === "urgent_expedite" ? "urgent expedite" : "standard reorder") + "</button></div>",
      "<textarea class=\"draft-textarea\" data-draft-textarea>" + escapeHtml(buildSupplierDraft(selected, templateKey)) + "</textarea>",
      "</div>",
      "</div>",
      "</section>"
    ].join("");
  }

  function renderFormulas() {
    var rootEl = document.querySelector("[data-formulas-root]");
    if (!rootEl) return;
    rootEl.innerHTML = [
      "<section class=\"panel\">",
      "<div class=\"panel-header\"><div><h2>Formulas and caveats</h2><p>These are transparent planning heuristics, not forecast guarantees.</p></div></div>",
      "<div class=\"formula-grid\">",
      formulaCard("Available inventory", "available_inventory = max(0, inventory_on_hand - committed_units). Missing committed_units defaults to 0."),
      formulaCard("Daily velocity", "daily_velocity = max(units_sold_30d / 30, units_sold_90d / 90). This is conservative and can over-order when demand is falling."),
      formulaCard("Days of cover", "days_of_cover = effective_inventory / daily_velocity, where effective_inventory = available_inventory + incoming_units. Zero velocity displays No recent sales."),
      formulaCard("Safety buffer", "safety_buffer_days = max(7, ceil(0.25 * lead_time_days)). Long lead times get larger buffers."),
      formulaCard("Stockout urgency", "EXPEDITE when days_of_cover < lead_time_days. REORDER when days_of_cover < lead_time_days + safety_buffer_days. Otherwise HOLD."),
      formulaCard("Reorder quantity", "reorder_quantity covers lead_time_days + 30 days minus effective_inventory, rounded up to reorder_multiple when present."),
      formulaCard("Deadstock candidate", "Rows with inventory and more than 180 days of cover are surfaced as candidates. Confirm seasonality before markdown decisions."),
      formulaCard("Caveat triggers", "Newly active SKU: units_sold_90d < units_sold_30d * 2.5. Verify net of returns before trusting sales velocity. Bundles and kits are not exploded into components.")
      + "</div></section>"
    ].join("");
  }

  function formulaCard(title, body) {
    return "<article class=\"formula-card\"><h3>" + escapeHtml(title) + "</h3><p>" + escapeHtml(body) + "</p></article>";
  }

  function renderAll() {
    hideEmptyState();
    if (!state.rows.length) return;
    state.summary = summarizePortfolio(state.rows);
    state.dataQuality = summarizeDataQuality(state.headers, state.rows, []);
    renderOverview();
    renderStockout();
    renderDeadstock();
    renderSupplier();
    renderFormulas();
    var stockoutCount = document.querySelector("[data-nav-count='stockout']");
    var deadstockCount = document.querySelector("[data-nav-count='deadstock']");
    if (stockoutCount) stockoutCount.textContent = state.summary.stockoutHigh || "";
    if (deadstockCount) deadstockCount.textContent = state.summary.deadstock || "";
  }

  function loadCsvText(text, label, source) {
    setStatus("Checking your CSV...", "Calculating SKU risk locally in your browser.");
    showErrors([]);
    var result = analyzeCsv(text);
    if (!result.ok) {
      state.rows = [];
      state.summary = null;
      state.dataQuality = null;
      hideEmptyState();
      clearResultRoots();
      setStatus("CSV needs cleanup", "Validation stopped before analysis.");
      showErrors(result.errors);
      track("csv_validation_error", { errors: result.errors.length });
      return false;
    }
    state.rows = result.rows;
    state.headers = result.headers;
    state.dataQuality = result.dataQuality;
    state.summary = result.summary;
    state.selectedSku = null;
    state.templateOverride = null;
    showErrors([]);
    setStatus(label || "CSV loaded", label === "Sample data loaded" ? "Review the result flow before uploading your own file." : "Analysis complete. Results are processed locally in this browser.");
    renderAll();
    if (source === "sample") track("sample_loaded", { rows: state.rows.length });
    if (source === "upload") track("csv_uploaded", { rows: state.rows.length });
    track("results_rendered", { rows: state.rows.length });
    return true;
  }

  function loadSample() {
    loadCsvText(SAMPLE_CSV, "Sample data loaded", "sample");
  }

  function setActiveTab(tab) {
    var validTabs = ["overview", "stockout", "deadstock", "supplier", "formulas"];
    if (validTabs.indexOf(tab) === -1) return;
    state.activeTab = tab;
    document.querySelectorAll("[data-tab-panel]").forEach(function panel(el) {
      el.classList.toggle("is-active", el.getAttribute("data-tab-panel") === tab);
    });
    document.querySelectorAll("[data-tab-target]").forEach(function nav(el) {
      el.classList.toggle("is-active", el.getAttribute("data-tab-target") === tab);
    });
    track("module_viewed", { tab: tab });
  }

  function handleLeadEdit(input) {
    var sku = input.getAttribute("data-lead-edit");
    var value = Number(input.value);
    if (!Number.isFinite(value) || value < 0 || value > 365) {
      showErrors(["lead_time_days must be between 0 and 365 for SKU " + sku]);
      return;
    }
    state.rows = state.rows.map(function update(row) {
      return row.sku === sku ? recalcRowForLeadTimeEdit(row, value) : row;
    });
    if (state.selectedSku === sku) state.templateOverride = null;
    showErrors([]);
    renderAll();
    track("lead_time_edited", { lead_time_days: Math.round(value) });
  }

  function selectSupplier(sku) {
    state.selectedSku = sku;
    state.templateOverride = null;
    renderSupplier();
    setActiveTab("supplier");
  }

  function initUi() {
    document.addEventListener("click", function onClick(event) {
      var sampleButton = event.target.closest("[data-sample-button]");
      var tabButton = event.target.closest("[data-tab-target]");
      var schemaButton = event.target.closest("[data-schema-toggle]");
      var sortButton = event.target.closest("[data-sort-stockout]");
      var selectButton = event.target.closest("[data-select-supplier]");
      var toggleButton = event.target.closest("[data-toggle-action]");
      var switchButton = event.target.closest("[data-switch-template]");
      var copyButton = event.target.closest("[data-copy-draft]");
      var primaryCta = event.target.closest(".primary-button");

      if (sampleButton) loadSample();
      if (primaryCta && !sampleButton) track("cta_clicked", { cta: "upload_csv" });
      if (tabButton) setActiveTab(tabButton.getAttribute("data-tab-target"));
      if (schemaButton) {
        var panel = document.querySelector("[data-schema-panel]");
        if (panel) panel.hidden = !panel.hidden;
      }
      if (sortButton) {
        var key = sortButton.getAttribute("data-sort-stockout");
        state.stockoutSort.direction = state.stockoutSort.key === key && state.stockoutSort.direction === "asc" ? "desc" : "asc";
        state.stockoutSort.key = key;
        renderStockout();
      }
      if (selectButton) selectSupplier(selectButton.getAttribute("data-select-supplier"));
      if (toggleButton) {
        var card = document.querySelector("[data-action-card='" + toggleButton.getAttribute("data-toggle-action") + "']");
        if (card) {
          card.classList.toggle("is-open");
          if (card.classList.contains("is-open")) track("action_row_expanded");
        }
      }
      if (switchButton) {
        state.templateOverride = switchButton.getAttribute("data-switch-template");
        renderSupplier();
        track("supplier_template_switched", { template: analyticsTemplateName(state.templateOverride) });
      }
      if (copyButton) {
        var textarea = document.querySelector("[data-draft-textarea]");
        if (textarea) {
          var selected = selectedSupplierRow();
          var templateKey = state.templateOverride || (selected ? selected.defaultTemplate : "standard_reorder");
          track("supplier_draft_copied", { template: analyticsTemplateName(templateKey) });
          textarea.select();
          navigator.clipboard.writeText(textarea.value).then(function copied() {
            copyButton.textContent = "Copied";
            setTimeout(function reset() { copyButton.textContent = "Copy draft"; }, 1400);
          }).catch(function fallback() {
            document.execCommand("copy");
          });
        }
      }
    });

    document.addEventListener("change", function onChange(event) {
      if (event.target.matches("[data-file-input]")) {
        var file = event.target.files && event.target.files[0];
        if (!file) return;
        setStatus("Checking your CSV...", "Parsing " + file.name + " locally in your browser.");
        file.text().then(function read(text) {
          loadCsvText(text, file.name + " loaded", "upload");
        }).catch(function error() {
          showErrors(["Could not read file: " + file.name]);
          track("csv_validation_error", { errors: 1 });
        });
      }
      if (event.target.matches("[data-lead-edit]")) handleLeadEdit(event.target);
    });

    renderFormulas();
  }

  var api = {
    track: track,
    parseCsv: parseCsv,
    validateHeaders: validateHeaders,
    validateRows: validateRows,
    normalizeRow: normalizeRow,
    computeSafetyBufferDays: computeSafetyBufferDays,
    calculateInventoryMetrics: calculateInventoryMetrics,
    evaluateCaveats: evaluateCaveats,
    determineAction: determineAction,
    selectSupplierTemplate: selectSupplierTemplate,
    buildSupplierDraft: buildSupplierDraft,
    summarizeDataQuality: summarizeDataQuality,
    summarizePortfolio: summarizePortfolio,
    recalcRowForLeadTimeEdit: recalcRowForLeadTimeEdit,
    analyzeCsv: analyzeCsv,
    SAMPLE_CSV: SAMPLE_CSV
  };

  root.InventoryStockoutApp = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof document !== "undefined") initUi();
}(typeof window !== "undefined" ? window : globalThis));
